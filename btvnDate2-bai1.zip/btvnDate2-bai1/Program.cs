﻿using System;
using System.Runtime.ExceptionServices;

namespace btvnDate2;
public class btvnDate2bai1
{
    public static void Main()
    {
        int arrCheck1, arrCheck2;
        bool isNotduplicated = false;

        int[] listArray = { 1, 2, 3, 2, 1 };

        for (arrCheck1 = 0; arrCheck1 < listArray.Length; arrCheck1++)
        {
            isNotduplicated = true;

            for (arrCheck2 = 0; arrCheck2 < listArray.Length; arrCheck2++)
            {
                if (arrCheck1 == arrCheck2)
                    continue;
                if (listArray[arrCheck1] == listArray[arrCheck2])
                {
                    isNotduplicated = false;
                    break;
                }
            }
            if (isNotduplicated)
            {
                Console.WriteLine("So khong bi trung la {0}", listArray[arrCheck1]);
                break;
            }
        }
        if (!isNotduplicated)
        {
            Console.WriteLine("So nao cung trung");
        }

    }
}