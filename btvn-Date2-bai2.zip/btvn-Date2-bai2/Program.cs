﻿using System;
using System.Collections.Generic;

namespace btvnDate2
{
    public class btvnDate2bai2 
    {
        public static void Main()
        {
            string name;
            float score;
            Console.WriteLine("Ung dung sap xep danh sach hoc sinh theo diem!");

            //Tao danh sach hoc sinh
            List<Student> students = new List<Student>();

            //Vong lap de nguoi dung input thong tin hoc sinh cho toi khi nguoi dung muon dung lai
            while (true) 
            {
                Console.WriteLine("Dien ten hoc sinh (hoac dien 'exit' de ket thuc)");
                name = Console.ReadLine();
                
                //ToLower de luon dam bao input cua nguoi dung giong voi dieu kien thoat vong lap bang cach covert string nhap vao sang lowercase.
                if (name.ToLower() == "exit") 
                    break;

                //Cho nguoi choi nhap diem cua hoc sinh, dong thoi check chi nhan cu phap dang int.
                Console.WriteLine("Nhap diem cua hoc sinh: ");
                if (float.TryParse(Console.ReadLine(), out score)) //Convert input cua user thanh float va luu vao bien score | TryParse de luu input vao bien score.
                {
                    //Neu convert so diem thanh cong, tao object "Student" va bo vao danh sach
                    Student student = new Student
                    {
                        Name = name,
                        Score = score
                    };
                    students.Add(student);
                }
                else
                {
                    Console.WriteLine("Cu phap sai, xin nhap so diem hop le");
                }
            }
            // Loc danh sach hoc sinh dua theo diem so tu cao toi thap
            students.Sort((s1, s2) => s2.Score.CompareTo(s1.Score));

            //In danh sach da duoc sap xep
            Console.WriteLine("\nDanh sach hoc sinh sap xep theo diem giam dan: ");
            //In tung object trong list ra ngoai
            foreach (var student in students) 
            {
                Console.WriteLine($"{student.Name} - {student.Score}");
            }

        }
    }

    //tao class Student, co cac thong so la Name va Score duoc lay tu danh sach nguoi dung dien vao.
    public class Student
    {
        public string Name { get; set; }
        public float Score { get; set; }
    }
}